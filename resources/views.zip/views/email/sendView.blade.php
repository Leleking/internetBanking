Please login with your account number,pin and password after verifying your identification.
<div>
    <p>Username: {{$user->name}}</p>
    <p>email: {{$user->email}}</p>
    <p>password: {{$password}}</p>
    <p>Account Number :{{$user->account->acct_num}} </p>
    <p>Account Pin : {{$user->account->pin}}</p>
</div>