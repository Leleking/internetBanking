<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class transaction extends Model
{
    //
}
